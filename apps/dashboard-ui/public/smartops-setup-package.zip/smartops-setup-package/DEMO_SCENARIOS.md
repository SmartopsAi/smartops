# Demo Scenarios

## Scenario 1: Resource anomaly -> scale up

1. Run the resource anomaly scenario in Demo Lab.
2. Show anomaly detection and RCA evidence.
3. Show policy decision and priority matrix.
4. Show scale action and verification result.

## Scenario 2: Error anomaly -> restart

1. Run the error anomaly scenario.
2. Show RCA cause and restart policy match.
3. Show orchestrator action evidence.
4. Show verification recovery state.

## Scenario 3: Repeated restart -> guardrail blocked

1. Run repeated restart/cooldown scenario.
2. Explain guardrail protection and rate limiting.
3. Show blocked decision and evidence.

## Unknown anomaly -> policy draft flow

1. Trigger or wait for an anomaly with no matching policy.
2. Review unmatched anomaly store.
3. Generate AI draft DSL for human review.
4. Validate draft DSL.
5. Save as disabled draft, then enable/reload only after approval.

## Viva script

Start with Live Dashboard for production state, switch to Demo Lab for scenarios, open Evidence Timeline for audit, show Policy Studio for DSL validation and draft workflow, then show Settings/Notifications and Integrations for deployment readiness.
