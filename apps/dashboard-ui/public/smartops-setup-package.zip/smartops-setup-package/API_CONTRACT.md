# SmartOps Dashboard API Contract

Base path examples assume Dashboard API is exposed behind your ingress or port-forward. Protected endpoints require:

```http
X-SmartOps-Admin-Key: <admin-key>
```

## Health and Dashboard

| Method | Endpoint | Purpose | Protected |
| --- | --- | --- | --- |
| GET | `/api/healthz` | Dashboard API health check | No |
| GET | `/api/dashboard/state` | Live dashboard state, summary, evidence, signals | No |
| GET | `/api/services/metrics` | Service metrics summary | No |
| GET | `/api/signals/recent` | Recent anomaly/RCA signals | No |

## Demo and Operations

| Method | Endpoint | Purpose | Protected |
| --- | --- | --- | --- |
| POST | `/api/scenarios/run` | Run guided demo scenario | No |
| POST | `/api/actions/trigger` | Trigger approved manual action | No in current demo API; restrict before production |
| POST | `/api/verification` | Run verification check | No |

## Policy Studio

| Method | Endpoint | Purpose | Protected |
| --- | --- | --- | --- |
| GET | `/api/policies/definitions` | List policy definitions | No |
| POST | `/api/policies/validate` | Validate draft DSL only | No |
| POST | `/api/policies/definitions` | Create disabled draft policy | Yes |
| PUT | `/api/policies/definitions/{id}` | Update policy and disable it for safety | Yes |
| DELETE | `/api/policies/definitions/{id}` | Soft-delete policy | Yes |
| POST | `/api/policies/definitions/{id}/enable` | Enable validated policy | Yes |
| POST | `/api/policies/definitions/{id}/disable` | Disable policy | Yes |
| POST | `/api/policies/reload` | Validate/reload active policy set | Yes |
| GET | `/api/policies/unmatched-anomalies` | List anomalies without matching policy | No |
| POST | `/api/policies/generate-draft` | Generate AI draft DSL for human review | Yes |

## Notifications

| Method | Endpoint | Purpose | Protected |
| --- | --- | --- | --- |
| GET | `/api/notifications/settings` | Read redacted notification settings | No |
| POST | `/api/notifications/settings` | Save non-secret routing settings | Yes |
| POST | `/api/notifications/test` | Send/mock test notification | Yes |
| POST | `/api/notifications/send` | Send/mock alert notification | Yes |

## Request Examples

```bash
curl http://<dashboard-api>/api/dashboard/state
```

```bash
curl -X POST http://<dashboard-api>/api/policies/validate \
  -H 'Content-Type: application/json' \
  -d '{"dsl":"POLICY \"example\":\n  WHEN anomaly.type == \"error\"\n  THEN restart(service)\n  PRIORITY 200","mode":"draft"}'
```

```bash
curl -X POST http://<dashboard-api>/api/notifications/test \
  -H 'Content-Type: application/json' \
  -H 'X-SmartOps-Admin-Key: <admin-key>' \
  -d '{"channels":["dashboard"],"message":"SmartOps test","updated_by":"operator"}'
```
