# Policy DSL Guide

SmartOps policies are written as small DSL rules. Policies are validated before save, saved disabled by default, and only affect runtime after enable/reload.

## Syntax

```text
POLICY "policy_name":
  WHEN anomaly.type == "resource"
       AND anomaly.score >= 0.9
  THEN scale(service, 4)
  PRIORITY 210
```

The action target must be the literal token `service`.

## Scale example

```text
POLICY "scale_up_on_resource":
  WHEN anomaly.type == "resource"
       AND anomaly.score >= 0.9
       AND k8s.replicas.current < 4
  THEN scale(service, 4)
  PRIORITY 210
```

## Restart example

```text
POLICY "restart_on_error":
  WHEN anomaly.type == "error"
       AND anomaly.score >= 0.9
  THEN restart(service)
  PRIORITY 250
```

## Guardrails

- Allowed actions are scale and restart.
- Replica bounds are expected to stay within the configured safe range.
- Restart policies should use cooldown/rate-limit protection.
- Unknown deployments or namespaces should be rejected by validation or runtime guardrails.

## Safe edit flow

1. Validate DSL draft.
2. Save policy as disabled/draft.
3. Human review.
4. Enable selected policy.
5. Reload active policy set.
6. Review audit log.

## AI policy drafts

AI generation only creates draft DSL. It must not save, enable, reload, deploy, or execute a policy automatically. Human approval and parser/guardrail validation are mandatory.
