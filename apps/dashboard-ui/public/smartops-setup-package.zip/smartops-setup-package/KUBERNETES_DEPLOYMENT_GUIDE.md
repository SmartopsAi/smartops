# Kubernetes Deployment Guide

These samples target Kubernetes and can be adapted for DigitalOcean Kubernetes or another managed cluster.

## 1. Namespace

```bash
kubectl create namespace smartops-dev
```

You may use another namespace, but update every manifest and policy scope consistently.

## 2. Persistent volumes

Apply PVCs first:

```bash
kubectl apply -f k8s-samples/policy-audit-pvc.yaml
kubectl apply -f k8s-samples/policy-store-pvc.yaml
```

## 3. Secrets

Create secrets with placeholder values replaced locally. Do not commit real values.

```bash
kubectl -n smartops-dev create secret generic smartops-admin-secret \
  --from-literal=SMARTOPS_ADMIN_API_KEY='<replace-me>'

kubectl -n smartops-dev create secret generic smartops-openai-secret \
  --from-literal=OPENAI_API_KEY='<replace-me>' \
  --from-literal=OPENAI_MODEL='gpt-4o-mini'

kubectl -n smartops-dev create secret generic smartops-sendgrid-secret \
  --from-literal=EMAIL_PROVIDER='sendgrid' \
  --from-literal=SENDGRID_API_KEY='<replace-me>' \
  --from-literal=SENDGRID_FROM_EMAIL='<replace-me>'

kubectl -n smartops-dev create secret generic smartops-twilio-secret \
  --from-literal=TWILIO_ACCOUNT_SID='<replace-me>' \
  --from-literal=TWILIO_AUTH_TOKEN='<replace-me>' \
  --from-literal=TWILIO_WHATSAPP_FROM='whatsapp:+14155238886' \
  --from-literal=TWILIO_WHATSAPP_TO='whatsapp:<replace-me>'
```

## 4. Images and registry

The sample manifests use `<YOUR_REGISTRY>` placeholders. Replace them with your image registry, for example a DigitalOcean Container Registry path. Do not include registry credentials in manifests.

## 5. Deploy services

```bash
kubectl apply -f k8s-samples/policy-engine.yaml
kubectl apply -f k8s-samples/orchestrator.yaml
kubectl apply -f k8s-samples/agent-detect.yaml
kubectl apply -f k8s-samples/agent-diagnose.yaml
kubectl apply -f k8s-samples/erp-simulator.yaml
kubectl apply -f k8s-samples/dashboard-api.yaml
kubectl apply -f k8s-samples/dashboard-ui.yaml
```

## 6. Verify

```bash
kubectl -n smartops-dev get pods
kubectl -n smartops-dev get svc
kubectl -n smartops-dev logs deployment/smartops-dashboard-api
```

## 7. Ingress or load balancer

Expose Dashboard UI and Dashboard API through your ingress controller or load balancer. Replace hostnames and load balancer values with your own values.
