# Notification Setup Guide

SmartOps supports dashboard notifications, email routing, and WhatsApp routing through backend-only providers.

## Channels

- Dashboard: internal/mock channel for review and audit.
- Email: Gmail SMTP and SendGrid HTTPS provider support.
- WhatsApp: Twilio WhatsApp REST API support.

## Cloud email recommendation

SMTP ports can be blocked in Kubernetes cloud environments. SendGrid over HTTPS 443 is recommended for cloud deployments.

## Required secrets

Use Kubernetes Secrets or a cloud secret manager. Do not place these values in frontend code or ZIP files.

```text
SMARTOPS_ADMIN_API_KEY=<replace-me>
OPENAI_API_KEY=<replace-me>
EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=<replace-me>
SENDGRID_FROM_EMAIL=<replace-me>
SMTP_USERNAME=<replace-me>
SMTP_PASSWORD=<replace-me>
TWILIO_ACCOUNT_SID=<replace-me>
TWILIO_AUTH_TOKEN=<replace-me>
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
TWILIO_WHATSAPP_TO=whatsapp:<replace-me>
```

## Safety rules

- Notification write/test/send endpoints require `X-SmartOps-Admin-Key`.
- Notification settings store routing metadata only, never provider secrets.
- Backend services handle provider calls, retry policy, audit, and rate limiting.
- Use mock mode until provider credentials and recipient authorization are reviewed.
