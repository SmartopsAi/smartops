# SmartOps Integration Guide

SmartOps can integrate with ERP systems, cloud services, or Kubernetes workloads that expose operational telemetry or anomaly signals.

## Supported inputs

- Prometheus metrics such as latency, error rate, CPU, memory, queue depth, and replica count.
- Logs from workload containers or platform components.
- Traces from OpenTelemetry-compatible services.
- Direct anomaly signal APIs from external monitoring systems.

## Closed-loop flow

1. Monitor: telemetry is collected from workloads and observability tools.
2. Detect: Agent Detect emits an anomaly signal with service, type, score, and window ID.
3. Diagnose: Agent Diagnose enriches the signal with RCA evidence.
4. Decide: Policy Engine evaluates DSL policies, priority matrix, and guardrails.
5. Act: Orchestrator executes approved remediation against allowed Kubernetes targets.
6. Verify: Dashboard API records verification outcome and evidence.

## Mapping an external workload

External teams should define:

- Workload service name, for example `erp-simulator` or `payments-api`.
- Kubernetes namespace, default example `smartops-dev`.
- Deployment names that SmartOps is allowed to scale or restart.
- Metrics and labels used to detect anomaly windows.
- Allowed remediation actions, such as scale or restart.
- Policy DSL rules and guardrails for each action.

## Integration boundary

SmartOps should not receive cloud credentials or database credentials through frontend code. All provider credentials belong in backend services, Kubernetes Secrets, or a cloud secret manager.
