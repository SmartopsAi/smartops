# SmartOps Setup Package

SmartOps is an AI-driven operations control plane for Kubernetes-hosted ERP and cloud workloads. It observes workload telemetry, detects anomalies, diagnoses likely root causes, evaluates remediation policies, executes approved actions through an orchestrator, and verifies recovery evidence.

## What this package contains

- Sanitized Kubernetes sample manifests for SmartOps services.
- Helm source samples for the SmartOps chart, with generated archives and secret-bearing output excluded.
- Dashboard API contract for integration and panel review.
- Integration guide for connecting external workloads through metrics, logs, traces, or anomaly signals.
- Policy DSL guide with validation, guardrails, and enable/reload flow.
- Notification setup guide for dashboard, email, and WhatsApp channels.
- Demo scenario guide for viva/panel walkthroughs.
- Sample environment template with placeholders only.

## How external teams use this package

1. Review `INTEGRATION_GUIDE.md` to map workload names, metrics, logs, traces, and deployment targets.
2. Review `KUBERNETES_DEPLOYMENT_GUIDE.md` before applying any manifests.
3. Replace placeholders in `sample-env.template` and create Kubernetes Secrets manually.
4. Update image registry references from `<YOUR_REGISTRY>` to your own registry.
5. Deploy PVCs, policy engine, dashboard API/UI, orchestrator, agents, ERP workload, and observability routes.
6. Validate APIs with `API_CONTRACT.md`.
7. Run the demo scenarios from `DEMO_SCENARIOS.md`.

## Security note

This package intentionally contains no real secrets, kubeconfig, registry credentials, API keys, SMTP passwords, SendGrid keys, Twilio tokens, OpenAI keys, or admin API keys. Replace every `<replace-me>` placeholder and create secrets in Kubernetes or a cloud secret manager before deployment.
